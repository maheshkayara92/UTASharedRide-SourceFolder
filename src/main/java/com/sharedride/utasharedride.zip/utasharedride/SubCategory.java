package com.sharedride.utasharedride;

/**
 * Created by Mahesh Kayara on 4/15/16.
 */
public class SubCategory {

    private String subcat_name;
    private String subcat_code;

    public void setSubCatName(String subcat_name)
    {
        this.subcat_name=subcat_name;
    }

    public String getSubCatName()
    {
        return subcat_name;
    }

    public void setSubCatCode(String subcat_code)
    {
        this.subcat_code=subcat_code;
    }

    public String getSubCatCode()
    {
        return subcat_code;
    }
}
